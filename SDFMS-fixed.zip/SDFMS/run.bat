javac *.java
java Main
